export const BASE_URL = "https://traveller.talrop.works/api/v1";
